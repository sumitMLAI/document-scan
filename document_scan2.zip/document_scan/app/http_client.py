import httpx
from app.config import get_settings


def build_client() -> httpx.AsyncClient:
    cfg = get_settings()
    return httpx.AsyncClient(
        base_url=cfg.trinsic_base_url,
        headers={
            "Authorization": f"Bearer {cfg.trinsic_api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
        timeout=30.0,
    )
