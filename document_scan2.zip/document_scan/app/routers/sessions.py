from typing import Annotated
from fastapi import APIRouter, Depends
from fastapi.responses import Response
import app.trinsic_client as trinsic
from app.config import Settings, get_settings
from app.schemas import (
    AttachmentFetchRequest,
    CreateDirectSessionRequest,
    CreateHostedSessionRequest,
    CreateWidgetSessionRequest,
    NativeChallengeResponseRequest,
    RecommendProvidersRequest,
    SessionResultsRequest,
)

router = APIRouter(tags=["Sessions"])

SettingsDep = Annotated[Settings, Depends(get_settings)]


# ---------------------------------------------------------------------------
# Create
# ---------------------------------------------------------------------------

@router.post("/sessions/widget")
async def create_widget_session(body: CreateWidgetSessionRequest, cfg: SettingsDep):
    return await trinsic.create_widget_session(
        profile_id=cfg.trinsic_verification_profile_id,
        redirect_url=body.redirect_url,
        allowed_provider_ids=body.allowed_provider_ids,
        user_info=body.user_info,
    )


@router.post("/sessions/hosted")
async def create_hosted_session(body: CreateHostedSessionRequest, cfg: SettingsDep):
    return await trinsic.create_hosted_session(
        profile_id=cfg.trinsic_verification_profile_id,
        provider_id=body.provider_id,
        redirect_url=body.redirect_url,
        provider_input=body.provider_input,
    )


@router.post("/sessions/direct")
async def create_direct_session(body: CreateDirectSessionRequest, cfg: SettingsDep):
    return await trinsic.create_direct_session(
        profile_id=cfg.trinsic_verification_profile_id,
        provider_id=body.provider_id,
        redirect_url=body.redirect_url,
        capabilities=body.capabilities,
        fallback_to_hosted_ui=body.fallback_to_hosted_ui,
        provider_input=body.provider_input,
    )


# ---------------------------------------------------------------------------
# Manage
# ---------------------------------------------------------------------------

@router.get("/sessions/list")
async def list_sessions(cfg: SettingsDep):
    return await trinsic.list_sessions(cfg.trinsic_verification_profile_id)


@router.post("/sessions/recommend-providers")
async def recommend_providers(body: RecommendProvidersRequest, cfg: SettingsDep):
    return await trinsic.recommend_providers(
        profile_id=cfg.trinsic_verification_profile_id,
        phone_number=body.phone_number,
        country_code=body.country_code,
    )


@router.get("/sessions/{session_id}")
async def get_session(session_id: str):
    return await trinsic.get_session(session_id)


# ---------------------------------------------------------------------------
# Results & lifecycle
# ---------------------------------------------------------------------------

@router.post("/sessions/{session_id}/results")
async def get_session_results(session_id: str, body: SessionResultsRequest):
    return await trinsic.get_session_results(session_id, body.results_access_key)


@router.post("/sessions/{session_id}/redact")
async def redact_session(session_id: str):
    return await trinsic.redact_session(session_id)


@router.post("/sessions/{session_id}/cancel")
async def cancel_session(session_id: str):
    return await trinsic.cancel_session(session_id)


# ---------------------------------------------------------------------------
# Direct flow helpers
# ---------------------------------------------------------------------------

@router.post("/sessions/{session_id}/refresh-step-content")
async def refresh_step_content(session_id: str):
    return await trinsic.refresh_step_content(session_id)


@router.post("/sessions/{session_id}/native-challenge-response")
async def submit_native_challenge_response(
    session_id: str,
    body: NativeChallengeResponseRequest,
):
    return await trinsic.submit_native_challenge_response(session_id, body.challenge_response)


@router.post("/sessions/{session_id}/attachments/{attachment_id}/get")
async def get_attachment(session_id: str, attachment_id: str, body: AttachmentFetchRequest):
    data = await trinsic.get_attachment(session_id, attachment_id, body.results_access_key)
    return Response(content=data, media_type="application/octet-stream")
