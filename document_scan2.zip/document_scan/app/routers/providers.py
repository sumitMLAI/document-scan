from fastapi import APIRouter, Query
import app.trinsic_client as trinsic

router = APIRouter(prefix="/providers", tags=["Providers"])


@router.get("/")
async def list_providers(
    licensed: bool | None = Query(None, description="true = licensed only, false = unlicensed only"),
):
    return await trinsic.list_providers(licensed)


@router.get("/{provider_id}")
async def get_provider(provider_id: str):
    return await trinsic.get_provider(provider_id)
