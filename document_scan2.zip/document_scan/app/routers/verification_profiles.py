from fastapi import APIRouter
import app.trinsic_client as trinsic

router = APIRouter(prefix="/verification-profiles", tags=["Verification Profiles"])


@router.get("/")
async def list_verification_profiles():
    return await trinsic.list_verification_profiles()


@router.get("/{profile_id}")
async def get_verification_profile(profile_id: str):
    return await trinsic.get_verification_profile(profile_id)
