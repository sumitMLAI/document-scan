from __future__ import annotations
from typing import Any
from pydantic import BaseModel, ConfigDict


# ---------------------------------------------------------------------------
# Shared config: accept both camelCase (Trinsic) and snake_case (our API)
# ---------------------------------------------------------------------------
class _Base(BaseModel):
    model_config = ConfigDict(populate_by_name=True)


# ---------------------------------------------------------------------------
# Requests
# ---------------------------------------------------------------------------

class CreateWidgetSessionRequest(_Base):
    redirect_url: str | None = None
    allowed_provider_ids: list[str] | None = None
    user_info: dict[str, Any] | None = None


class CreateHostedSessionRequest(_Base):
    provider_id: str
    redirect_url: str
    provider_input: dict[str, Any] | None = None


class CreateDirectSessionRequest(_Base):
    provider_id: str
    redirect_url: str
    # LaunchBrowser | DeeplinkToMobile | ShowContent | NativeChallenge
    # CaptureRedirect | PollResult | RefreshStepContent | PollAfterRedirect
    capabilities: list[str]
    fallback_to_hosted_ui: bool = True
    provider_input: dict[str, Any] | None = None


class RecommendProvidersRequest(_Base):
    phone_number: str | None = None
    country_code: str | None = None  # ISO 3166-1 alpha-2


class SessionResultsRequest(_Base):
    results_access_key: str


class NativeChallengeResponseRequest(_Base):
    challenge_response: str


class AttachmentFetchRequest(_Base):
    results_access_key: str


# ---------------------------------------------------------------------------
# Responses — normalised identity model
# ---------------------------------------------------------------------------

class AddressData(_Base):
    full_address: str | None = None
    line1: str | None = None
    line2: str | None = None
    line3: str | None = None
    city: str | None = None
    subdivision: str | None = None   # state / province (ISO 3166-2)
    postal_code: str | None = None
    country: str | None = None       # ISO 3166-1 alpha-2


class PersonData(_Base):
    given_name: str | None = None
    family_name: str | None = None
    middle_name: str | None = None
    full_name: str | None = None
    suffix: str | None = None
    date_of_birth: str | None = None  # ISO 8601
    nationality: str | None = None    # ISO 3166-1 alpha-2
    sex: str | None = None            # "male" | "female" | "unknown"
    phone_number: str | None = None
    address: AddressData | None = None


class DocumentData(_Base):
    type: str | None = None               # "passport" | "drivers_license" | …
    number: str | None = None
    issue_date: str | None = None         # ISO 8601
    expiration_date: str | None = None    # ISO 8601
    issuing_country: str | None = None    # ISO 3166-1 alpha-2
    issuing_authority: str | None = None
    issuing_subdivision: str | None = None  # ISO 3166-2 (Feb 2026+)


class MatchData(_Base):
    national_id_number: bool | None = None
    full_name: bool | None = None
    given_name: bool | None = None
    middle_name: bool | None = None
    family_name: bool | None = None
    sex: bool | None = None
    date_of_birth: bool | None = None
    face_match: float | None = None        # confidence 0–1
    liveness: float | None = None          # confidence 0–1
    image_authenticity: float | None = None


class Attachment(_Base):
    # types: selfie | documentFront | documentBack | documentPortrait
    #        documentSignature | provider.document-scan.report
    id: str
    type: str
    content_type: str   # MIME type
    size_bytes: int | None = None


class NormalizedIdentity(_Base):
    person: PersonData | None = None
    document: DocumentData | None = None
    match: MatchData | None = None
    attachments: list[Attachment] | None = None
    # kept for the 90-day backwards-compat window (deprecated Feb 2026)
    attachment_access_keys: dict[str, str] | None = None


class SessionOutcome(_Base):
    done: bool
    success: bool
    canceled: bool = False
    error_code: str | None = None
    error_message: str | None = None


class SessionResultResponse(_Base):
    session_id: str
    outcome: SessionOutcome
    normalized: NormalizedIdentity | None = None
    provider_output: dict[str, Any] | None = None
