import time
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import httpx

from app.config import get_settings
from app.database import get_client
from app.logger import get_logger
from app.routers import providers, sessions, verification_profiles

log = get_logger("app")


@asynccontextmanager
async def lifespan(_: FastAPI):
    cfg = get_settings()
    log.info("startup | env=%s profile=%s", cfg.environment, cfg.trinsic_verification_profile_id)
    yield
    get_client().close()
    log.info("shutdown | mongo connection closed")


def create_app() -> FastAPI:
    cfg = get_settings()

    app = FastAPI(
        title="Trinsic Identity Verification API",
        version="1.0.0",
        lifespan=lifespan,
    )

    # ── CORS ──────────────────────────────────────────────────────────────────
    origins = [o.strip() for o in cfg.cors_origins.split(",") if o.strip()]
    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins,
        allow_credentials=cfg.cors_allow_credentials,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ── Request / response logger ─────────────────────────────────────────────
    @app.middleware("http")
    async def log_requests(request: Request, call_next):
        start = time.perf_counter()
        response = await call_next(request)
        ms = (time.perf_counter() - start) * 1000
        log.info(
            "%s %s %s  %.1fms",
            request.method,
            request.url.path,
            response.status_code,
            ms,
        )
        return response

    # ── Routers ───────────────────────────────────────────────────────────────
    app.include_router(providers.router)
    app.include_router(sessions.router)
    app.include_router(verification_profiles.router)

    # ── Error handlers ────────────────────────────────────────────────────────
    @app.exception_handler(httpx.HTTPStatusError)
    async def handle_trinsic_error(request: Request, exc: httpx.HTTPStatusError):
        try:
            detail = exc.response.json()
        except Exception:
            detail = exc.response.text
        log.error(
            "trinsic error | %s %s → %s",
            request.method,
            request.url.path,
            exc.response.status_code,
        )
        return JSONResponse(
            status_code=exc.response.status_code,
            content={"error": "upstream_error", "detail": detail},
        )

    @app.get("/", tags=["Health"], include_in_schema=False)
    async def health():
        return {"status": "ok"}

    return app


app = create_app()
