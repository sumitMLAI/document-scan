from typing import Any
from app.http_client import build_client
from app.database import record_session
from app.logger import get_logger

log = get_logger("trinsic")


# ---------------------------------------------------------------------------
# Providers
# ---------------------------------------------------------------------------

async def list_providers(licensed: bool | None = None) -> dict:
    params = {}
    if licensed is not None:
        params["licensed"] = str(licensed).lower()
    async with build_client() as c:
        r = await c.get("/providers", params=params)
        r.raise_for_status()
        log.debug("list_providers licensed=%s", licensed)
        return r.json()


async def get_provider(provider_id: str) -> dict:
    async with build_client() as c:
        r = await c.get(f"/providers/{provider_id}")
        r.raise_for_status()
        log.debug("get_provider id=%s", provider_id)
        return r.json()


# ---------------------------------------------------------------------------
# Sessions — create
# ---------------------------------------------------------------------------

async def create_widget_session(
    profile_id: str,
    redirect_url: str | None,
    allowed_provider_ids: list[str] | None,
    user_info: dict[str, Any] | None,
) -> dict:
    body: dict[str, Any] = {"verificationProfileId": profile_id}
    if redirect_url:
        body["redirectUrl"] = redirect_url
    if allowed_provider_ids:
        body["allowedProviderIds"] = allowed_provider_ids
    if user_info:
        body["userInfo"] = user_info
    async with build_client() as c:
        r = await c.post("/sessions/widget", json=body)
        r.raise_for_status()
        data = r.json()
    await record_session("widget", body, data)
    log.info("session created | type=widget session_id=%s", data.get("sessionId"))
    return data


async def create_hosted_session(
    profile_id: str,
    provider_id: str,
    redirect_url: str,
    provider_input: dict[str, Any] | None,
) -> dict:
    body: dict[str, Any] = {
        "verificationProfileId": profile_id,
        "providerId": provider_id,
        "redirectUrl": redirect_url,
    }
    if provider_input:
        body["providerInput"] = provider_input
    async with build_client() as c:
        r = await c.post("/sessions/hosted", json=body)
        r.raise_for_status()
        data = r.json()
    await record_session("hosted", body, data)
    log.info("session created | type=hosted session_id=%s provider=%s", data.get("sessionId"), provider_id)
    return data


async def create_direct_session(
    profile_id: str,
    provider_id: str,
    redirect_url: str,
    capabilities: list[str],
    fallback_to_hosted_ui: bool,
    provider_input: dict[str, Any] | None,
) -> dict:
    body: dict[str, Any] = {
        "verificationProfileId": profile_id,
        "providerId": provider_id,
        "redirectUrl": redirect_url,
        "capabilities": capabilities,
        "fallbackToHostedUi": fallback_to_hosted_ui,
    }
    if provider_input:
        body["providerInput"] = provider_input
    async with build_client() as c:
        r = await c.post("/sessions/direct", json=body)
        r.raise_for_status()
        data = r.json()
    await record_session("direct", body, data)
    log.info("session created | type=direct session_id=%s provider=%s", data.get("sessionId"), provider_id)
    return data


# ---------------------------------------------------------------------------
# Sessions — manage
# ---------------------------------------------------------------------------

async def list_sessions(profile_id: str) -> dict:
    async with build_client() as c:
        r = await c.get(f"/verification-profiles/{profile_id}/sessions")
        r.raise_for_status()
        return r.json()


async def recommend_providers(
    profile_id: str,
    phone_number: str | None,
    country_code: str | None,
) -> dict:
    # POST /sessions/providers/recommend (moved from /network/recommend, Feb 2026)
    body: dict[str, Any] = {"verificationProfileId": profile_id}
    if phone_number:
        body["phoneNumber"] = phone_number
    if country_code:
        body["countryCode"] = country_code
    async with build_client() as c:
        r = await c.post("/sessions/providers/recommend", json=body)
        r.raise_for_status()
        return r.json()


async def get_session(session_id: str) -> dict:
    async with build_client() as c:
        r = await c.get(f"/sessions/{session_id}")
        r.raise_for_status()
        return r.json()


# ---------------------------------------------------------------------------
# Sessions — results & lifecycle
# ---------------------------------------------------------------------------

async def get_session_results(session_id: str, results_access_key: str) -> dict:
    async with build_client() as c:
        r = await c.post(
            f"/sessions/{session_id}/results",
            json={"resultsAccessKey": results_access_key},
        )
        r.raise_for_status()
        log.info("session results fetched | session_id=%s", session_id)
        return r.json()


async def redact_session(session_id: str) -> dict:
    async with build_client() as c:
        r = await c.post(f"/sessions/{session_id}/redact")
        r.raise_for_status()
        log.info("session redacted | session_id=%s", session_id)
        return r.json()


async def cancel_session(session_id: str) -> dict:
    async with build_client() as c:
        r = await c.post(f"/sessions/{session_id}/cancel")
        r.raise_for_status()
        log.info("session cancelled | session_id=%s", session_id)
        return r.json()


# ---------------------------------------------------------------------------
# Sessions — direct flow helpers
# ---------------------------------------------------------------------------

async def refresh_step_content(session_id: str) -> dict:
    async with build_client() as c:
        r = await c.post(f"/sessions/{session_id}/refresh-step-content")
        r.raise_for_status()
        return r.json()


async def submit_native_challenge_response(
    session_id: str,
    challenge_response: str,
) -> dict:
    async with build_client() as c:
        r = await c.post(
            f"/sessions/{session_id}/native-challenge-response",
            json={"challengeResponse": challenge_response},
        )
        r.raise_for_status()
        return r.json()


async def get_attachment(
    session_id: str,
    attachment_id: str,
    results_access_key: str,
) -> bytes:
    # POST /sessions/{id}/attachments/{attachmentId}/get  (Feb 2026+)
    async with build_client() as c:
        r = await c.post(
            f"/sessions/{session_id}/attachments/{attachment_id}/get",
            json={"resultsAccessKey": results_access_key},
        )
        r.raise_for_status()
        return r.content


# ---------------------------------------------------------------------------
# Verification profiles  (/valpha prefix — alpha API)
# ---------------------------------------------------------------------------

async def list_verification_profiles() -> dict:
    async with build_client() as c:
        r = await c.get("/valpha/verification-profiles")
        r.raise_for_status()
        return r.json()


async def get_verification_profile(profile_id: str) -> dict:
    async with build_client() as c:
        r = await c.get(f"/valpha/verification-profiles/{profile_id}")
        r.raise_for_status()
        return r.json()
