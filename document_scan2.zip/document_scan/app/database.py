from datetime import datetime, timezone
from typing import Any, Literal
from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorCollection
from app.config import get_settings
from app.logger import get_logger

log = get_logger("database")
SessionType = Literal["widget", "hosted", "direct"]

_client: AsyncIOMotorClient | None = None


def get_client() -> AsyncIOMotorClient:
    global _client
    if _client is None:
        cfg = get_settings()
        _client = AsyncIOMotorClient(cfg.mongo_uri)
        log.info("mongo connected | uri=%s db=%s", cfg.mongo_uri, cfg.mongo_db)
    return _client


def get_collection() -> AsyncIOMotorCollection:
    cfg = get_settings()
    return get_client()[cfg.mongo_db]["sessions"]


async def record_session(
    session_type: SessionType,
    request: dict[str, Any],
    response: dict[str, Any],
) -> None:
    """
    Insert one document per session creation.

    Schema:
      session_type  – "widget" | "hosted" | "direct"
      session_id    – Trinsic session ID (from response)
      request       – sanitised request payload sent to Trinsic
      response      – full response from Trinsic
      created_at    – UTC timestamp
    """
    doc = {
        "session_type": session_type,
        "session_id": response.get("sessionId"),
        "request": request,
        "response": response,
        "created_at": datetime.now(timezone.utc),
    }
    await get_collection().insert_one(doc)
    log.debug("session recorded | type=%s session_id=%s", session_type, doc["session_id"])
