from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    trinsic_api_key: str
    trinsic_base_url: str = "https://api.trinsic.id/api/v1"
    trinsic_verification_profile_id: str
    environment: str = "test"
    mongo_uri: str = "mongodb://localhost:27017"
    mongo_db: str = "trinsic"

    # CORS — comma-separated origins, e.g. "http://localhost:3000,https://app.example.com"
    # Use "*" to allow all origins (dev only)
    cors_origins: str = "*"
    cors_allow_credentials: bool = False

    # Uvicorn
    host: str = "0.0.0.0"
    port: int = 8000
    # workers=0 → auto-calculate from CPU count at runtime
    workers: int = 0

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")


@lru_cache
def get_settings() -> Settings:
    return Settings()
