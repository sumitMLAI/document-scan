"""
Entry point — run with:  python server.py
or via uvicorn directly: uvicorn app.main:app --reload
"""
import multiprocessing
import uvicorn
from app.config import get_settings
from app.logger import get_logger

log = get_logger("server")


def worker_count(configured: int) -> int:
    """
    If WORKERS is set to a positive value in .env, use it.
    Otherwise default to (CPU cores * 2) + 1, capped at 8.
    This formula is the standard Gunicorn recommendation for I/O-bound apps.
    """
    if configured > 0:
        return configured
    cores = multiprocessing.cpu_count()
    return min(cores * 2 + 1, 8)


if __name__ == "__main__":
    cfg = get_settings()
    workers = worker_count(cfg.workers)

    log.info("starting | host=%s port=%s workers=%s env=%s", cfg.host, cfg.port, workers, cfg.environment)

    uvicorn.run(
        "app.main:app",
        host=cfg.host,
        port=cfg.port,
        workers=workers,
        # reload only makes sense in dev with a single worker
        reload=cfg.environment == "dev" and workers == 1,
        log_level="info",
    )
