from fastapi import APIRouter
from app import trinsic_client as tc

router = APIRouter(prefix="/verification-profiles", tags=["Verification Profiles"])


@router.get("/")
async def list_verification_profiles():
    """List all verification profiles for the current organisation and environment."""
    return await tc.list_verification_profiles()


@router.get("/{profile_id}")
async def get_verification_profile(profile_id: str):
    """Get a specific verification profile by ID."""
    return await tc.get_verification_profile(profile_id)
