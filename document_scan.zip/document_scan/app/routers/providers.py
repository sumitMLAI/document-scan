from fastapi import APIRouter, Query
from app import trinsic_client as tc
from app.schemas import RecommendProvidersRequest

router = APIRouter(prefix="/providers", tags=["Providers"])


@router.get("/")
async def list_providers(licensed: bool | None = Query(None, description="Filter by license status")):
    """List all identity providers available to your organisation."""
    return await tc.list_providers(licensed=licensed)


@router.get("/{provider_id}")
async def get_provider(provider_id: str):
    """Get a single identity provider by ID."""
    return await tc.get_provider(provider_id)
