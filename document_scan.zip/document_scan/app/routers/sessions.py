"""
All session-related routes.

Hosted Provider Session flow:
  1. POST /profiles/{id}/sessions/hosted          → get launchUrl + sessionId
  2. Redirect user to launchUrl
  3. User completes verification, redirected back with ?resultsAccessKey=&sessionId=
  4. Frontend sends resultsAccessKey to backend
  5. POST /sessions/{sessionId}/results           → fetch identity data
  6. POST /sessions/{sessionId}/redact            → remove PII immediately
"""
from fastapi import APIRouter
from fastapi.responses import Response
from pydantic import BaseModel
from app import trinsic_client as tc
from app.schemas import (
    CreateHostedSessionRequest,
    CreateDirectSessionRequest,
    CreateWidgetSessionRequest,
    NativeChallengeResponseRequest,
    RecommendProvidersRequest,
    SessionResultsRequest,
)

router = APIRouter(tags=["Sessions"])


# ─── Widget session ────────────────────────────────────────────────────────────

@router.post("/sessions/widget")
async def create_widget_session(body: CreateWidgetSessionRequest):
    """
    Create a Widget Session.
    Trinsic's hosted widget handles provider selection + full verification UI.
    Returns sessionId, launchUrl, resultsAccessKey.
    """
    return await tc.create_widget_session(
        verification_profile_id=body.verification_profile_id,
        redirect_url=body.redirect_url,
        allowed_provider_ids=body.allowed_provider_ids,
        user_info=body.user_info,
    )


# ─── Per-profile session creation ─────────────────────────────────────────────

@router.post("/profiles/{verification_profile_id}/sessions/hosted")
async def create_hosted_session(
    verification_profile_id: str,
    body: CreateHostedSessionRequest,
):
    """
    Create a Hosted Provider Session.
    Trinsic's UI handles all complex provider interactions.
    Returns sessionId, launchUrl, and resultsAccessKey.
    """
    return await tc.create_hosted_provider_session(
        verification_profile_id=verification_profile_id,
        provider_id=body.provider_id,
        redirect_url=body.redirect_url,
        provider_input=body.provider_input,
    )


@router.post("/profiles/{verification_profile_id}/sessions/direct")
async def create_direct_session(
    verification_profile_id: str,
    body: CreateDirectSessionRequest,
):
    """
    Create a Direct Provider Session.
    Your UI handles the flow; Trinsic falls back to hosted UI for gaps.
    """
    return await tc.create_direct_provider_session(
        verification_profile_id=verification_profile_id,
        provider_id=body.provider_id,
        redirect_url=body.redirect_url,
        capabilities=body.capabilities,
        fallback_to_hosted_ui=body.fallback_to_hosted_ui,
        provider_input=body.provider_input,
    )


@router.get("/profiles/{verification_profile_id}/sessions")
async def list_sessions(verification_profile_id: str):
    """List all sessions for a verification profile."""
    return await tc.list_sessions(verification_profile_id)


@router.post("/profiles/{verification_profile_id}/recommend-providers")
async def recommend_providers(
    verification_profile_id: str,
    body: RecommendProvidersRequest,
):
    """
    Recommend the most relevant identity providers for a user.
    Uses network signals (phone number, country) to rank providers.
    """
    return await tc.recommend_providers(
        verification_profile_id=verification_profile_id,
        phone_number=body.phone_number,
        country_code=body.country_code,
    )


# ─── Per-session operations ────────────────────────────────────────────────────

@router.get("/sessions/{session_id}")
async def get_session(session_id: str):
    """Get session metadata (status, provider, timestamps). No PII returned."""
    return await tc.get_session(session_id)


@router.post("/sessions/{session_id}/results")
async def get_session_results(session_id: str, body: SessionResultsRequest):
    """
    Fetch full identity results for a completed session.
    Requires the resultsAccessKey received from the redirect callback.
    """
    return await tc.get_session_results(
        session_id=session_id,
        results_access_key=body.results_access_key,
    )


@router.post("/sessions/{session_id}/redact")
async def redact_session(session_id: str):
    """
    Immediately redact all PII for this session from Trinsic's servers.
    Call this right after consuming session results.
    """
    return await tc.redact_session(session_id)


@router.post("/sessions/{session_id}/cancel")
async def cancel_session(session_id: str):
    """Cancel an in-progress session."""
    return await tc.cancel_session(session_id)


@router.post("/sessions/{session_id}/refresh-step-content")
async def refresh_step_content(session_id: str):
    """
    Refresh expiring step content for a Direct Provider Session.
    Use when a provider's deeplink/QR code has a short TTL and needs renewal.
    """
    return await tc.refresh_step_content(session_id)


@router.post("/sessions/{session_id}/native-challenge-response")
async def submit_native_challenge_response(
    session_id: str,
    body: NativeChallengeResponseRequest,
):
    """
    Submit a native challenge response (e.g. mDL via Digital Credentials API,
    Google Wallet, Apple Wallet). Always paired with PerformNativeChallenge
    launch method in Direct Provider Sessions.
    """
    return await tc.submit_native_challenge_response(
        session_id=session_id,
        challenge_response=body.challenge_response,
    )


class AttachmentFetchRequest(BaseModel):
    results_access_key: str


@router.post("/sessions/{session_id}/attachments/{attachment_id}/get")
async def get_attachment(
    session_id: str,
    attachment_id: str,
    body: AttachmentFetchRequest,
):
    """
    Fetch the binary content of a session attachment (selfie, document scan, etc).
    Use the attachment id and type from the `attachments` array in session results.

    Attachment types: selfie, documentFront, documentBack, documentPortrait,
                      documentSignature, provider.document-scan.report
    Returns the raw binary with the appropriate Content-Type header.
    """
    data = await tc.get_attachment(
        session_id=session_id,
        attachment_id=attachment_id,
        results_access_key=body.results_access_key,
    )
    # Return as octet-stream; client should inspect Attachment.content_type
    # from session results to know the actual MIME type (e.g. image/png)
    return Response(content=data, media_type="application/octet-stream")
