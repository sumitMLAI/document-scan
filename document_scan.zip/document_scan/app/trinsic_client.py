"""
Async HTTP client wrapper for the Trinsic REST API.
Base URL: https://api.trinsic.id/api/v1
Auth:     Bearer token (TRINSIC_API_KEY)
"""
import httpx
from app.config import settings


def _client() -> httpx.AsyncClient:
    return httpx.AsyncClient(
        base_url=settings.trinsic_base_url,
        headers={
            "Authorization": f"Bearer {settings.trinsic_api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
        timeout=30.0,
    )


# ─── Providers ────────────────────────────────────────────────────────────────

async def list_providers(licensed: bool | None = None) -> dict:
    """GET /providers  – list all identity providers."""
    params = {}
    if licensed is not None:
        params["licensed"] = str(licensed).lower()
    async with _client() as c:
        r = await c.get("/providers", params=params)
        r.raise_for_status()
        return r.json()


async def get_provider(provider_id: str) -> dict:
    """GET /providers/{providerId}  – get a single provider."""
    async with _client() as c:
        r = await c.get(f"/providers/{provider_id}")
        r.raise_for_status()
        return r.json()


async def recommend_providers(
    verification_profile_id: str,
    phone_number: str | None = None,
    country_code: str | None = None,
) -> dict:
    """
    POST /verification-profiles/{verificationProfileId}/recommend-providers
    Returns providers most relevant to the user based on network signals.
    """
    body: dict = {}
    if phone_number:
        body["phoneNumber"] = phone_number
    if country_code:
        body["countryCode"] = country_code
    async with _client() as c:
        r = await c.post(
            f"/verification-profiles/{verification_profile_id}/recommend-providers",
            json=body,
        )
        r.raise_for_status()
        return r.json()


# ─── Sessions ─────────────────────────────────────────────────────────────────

async def create_hosted_provider_session(
    verification_profile_id: str,
    provider_id: str,
    redirect_url: str,
    provider_input: dict | None = None,
) -> dict:
    """
    POST /verification-profiles/{verificationProfileId}/sessions/hosted
    Creates a Hosted Provider Session – Trinsic owns the UI for complex flows.
    Returns: sessionId, launchUrl, resultsAccessKey
    """
    body: dict = {
        "providerId": provider_id,
        "redirectUrl": redirect_url,
    }
    if provider_input:
        body["providerInput"] = provider_input
    async with _client() as c:
        r = await c.post(
            f"/verification-profiles/{verification_profile_id}/sessions/hosted",
            json=body,
        )
        r.raise_for_status()
        return r.json()


async def create_direct_provider_session(
    verification_profile_id: str,
    provider_id: str,
    redirect_url: str,
    capabilities: list[str],
    fallback_to_hosted_ui: bool = True,
    provider_input: dict | None = None,
) -> dict:
    """
    POST /verification-profiles/{verificationProfileId}/sessions/direct
    Creates a Direct Provider Session – your UI handles the flow.
    capabilities examples: ["LaunchBrowser","CaptureRedirect"]
    """
    body: dict = {
        "providerId": provider_id,
        "redirectUrl": redirect_url,
        "capabilities": capabilities,
        "fallbackToHostedUi": fallback_to_hosted_ui,
    }
    if provider_input:
        body["providerInput"] = provider_input
    async with _client() as c:
        r = await c.post(
            f"/verification-profiles/{verification_profile_id}/sessions/direct",
            json=body,
        )
        r.raise_for_status()
        return r.json()


async def list_sessions(verification_profile_id: str) -> dict:
    """GET /verification-profiles/{verificationProfileId}/sessions"""
    async with _client() as c:
        r = await c.get(f"/verification-profiles/{verification_profile_id}/sessions")
        r.raise_for_status()
        return r.json()


async def get_session(session_id: str) -> dict:
    """GET /sessions/{sessionId}  – get session metadata (no PII)."""
    async with _client() as c:
        r = await c.get(f"/sessions/{session_id}")
        r.raise_for_status()
        return r.json()


async def get_session_results(session_id: str, results_access_key: str) -> dict:
    """
    GET /sessions/{sessionId}/results?resultsAccessKey=...
    Retrieves full identity data. resultsAccessKey is required.
    """
    async with _client() as c:
        r = await c.get(
            f"/sessions/{session_id}/results",
            params={"resultsAccessKey": results_access_key},
        )
        r.raise_for_status()
        return r.json()


async def redact_session(session_id: str) -> dict:
    """
    POST /sessions/{sessionId}/redact
    Immediately removes all PII from Trinsic's servers for this session.
    """
    async with _client() as c:
        r = await c.post(f"/sessions/{session_id}/redact")
        r.raise_for_status()
        return r.json()


async def cancel_session(session_id: str) -> dict:
    """
    POST /sessions/{sessionId}/cancel
    Cancel an in-progress session by its ID.
    """
    async with _client() as c:
        r = await c.post(f"/sessions/{session_id}/cancel")
        r.raise_for_status()
        return r.json()


async def create_widget_session(
    verification_profile_id: str,
    redirect_url: str | None = None,
    allowed_provider_ids: list[str] | None = None,
    user_info: dict | None = None,
) -> dict:
    """
    POST /sessions/widget
    Create a Widget Session – Trinsic's hosted widget handles provider
    selection and the full verification UI.
    Returns: sessionId, launchUrl, resultsAccessKey
    """
    body: dict = {"verificationProfileId": verification_profile_id}
    if redirect_url:
        body["redirectUrl"] = redirect_url
    if allowed_provider_ids:
        body["allowedProviderIds"] = allowed_provider_ids
    if user_info:
        body["userInfo"] = user_info
    async with _client() as c:
        r = await c.post("/sessions/widget", json=body)
        r.raise_for_status()
        return r.json()


async def refresh_step_content(session_id: str) -> dict:
    """
    POST /sessions/{sessionId}/refresh-step-content
    Refreshes expiring step content (e.g. short-lived deeplinks) for a
    Direct Provider Session.
    """
    async with _client() as c:
        r = await c.post(f"/sessions/{session_id}/refresh-step-content")
        r.raise_for_status()
        return r.json()


async def submit_native_challenge_response(
    session_id: str,
    challenge_response: str,
) -> dict:
    """
    POST /sessions/{sessionId}/native-challenge-response
    Submit the response from a native challenge (e.g. mDL via Digital
    Credentials API / Google Wallet / Apple Wallet).
    """
    async with _client() as c:
        r = await c.post(
            f"/sessions/{session_id}/native-challenge-response",
            json={"challengeResponse": challenge_response},
        )
        r.raise_for_status()
        return r.json()


async def get_attachment(
    session_id: str,
    attachment_id: str,
    results_access_key: str,
) -> bytes:
    """
    POST /sessions/{sessionId}/attachments/{attachmentId}/get
    Fetch the binary content of an attachment (image/pdf).
    Returns raw bytes; caller should set the correct Content-Type from
    the Attachment.content_type field returned in session results.
    (Feb 2026+ endpoint – replaces the deprecated POST /attachments/attachment)
    """
    async with _client() as c:
        r = await c.post(
            f"/sessions/{session_id}/attachments/{attachment_id}/get",
            json={"resultsAccessKey": results_access_key},
        )
        r.raise_for_status()
        return r.content


# ─── Verification Profiles ────────────────────────────────────────────────────

async def list_verification_profiles() -> dict:
    """
    GET /valpha/verification-profiles
    List all verification profiles for the current organisation & environment.
    """
    async with _client() as c:
        # Note: this endpoint lives under /valpha (alpha version prefix)
        r = await c.get("/valpha/verification-profiles")
        r.raise_for_status()
        return r.json()


async def get_verification_profile(profile_id: str) -> dict:
    """
    GET /valpha/verification-profiles/{id}
    Get a specific verification profile by ID.
    """
    async with _client() as c:
        r = await c.get(f"/valpha/verification-profiles/{profile_id}")
        r.raise_for_status()
        return r.json()
