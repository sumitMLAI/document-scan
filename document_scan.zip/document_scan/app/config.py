from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    trinsic_api_key: str
    trinsic_base_url: str = "https://api.trinsic.id/api/v1"
    environment: str = "test"

    class Config:
        env_file = ".env"


settings = Settings()
