"""
Pydantic schemas for Trinsic API requests and responses.

Result model hierarchy (GET /sessions/{id}/results):
  SessionResultResponse
    └── normalized: NormalizedIdentity
          ├── person:   PersonData
          │     └── address: AddressData
          ├── document: DocumentData
          ├── match:    MatchData
          └── attachments: list[Attachment]
    └── providerOutput: dict  (provider-specific raw output)
    └── outcome: SessionOutcome  (done, success, error)
"""
from __future__ import annotations
from pydantic import BaseModel
from typing import Any


# ─────────────────────────────────────────────────────────────────────────────
# REQUEST SCHEMAS
# ─────────────────────────────────────────────────────────────────────────────

class RecommendProvidersRequest(BaseModel):
    phone_number: str | None = None
    country_code: str | None = None  # ISO 3166-1 alpha-2, e.g. "US"


class CreateHostedSessionRequest(BaseModel):
    provider_id: str
    redirect_url: str
    provider_input: dict[str, Any] | None = None


class CreateDirectSessionRequest(BaseModel):
    provider_id: str
    redirect_url: str
    # Valid capability values:
    #   LaunchBrowser, DeeplinkToMobile, ShowContent, NativeChallenge,
    #   CaptureRedirect, PollResult, RefreshStepContent, PollAfterRedirect
    capabilities: list[str]
    fallback_to_hosted_ui: bool = True
    provider_input: dict[str, Any] | None = None


class CreateWidgetSessionRequest(BaseModel):
    verification_profile_id: str
    redirect_url: str | None = None
    allowed_provider_ids: list[str] | None = None
    user_info: dict[str, Any] | None = None


class SessionResultsRequest(BaseModel):
    results_access_key: str


class NativeChallengeResponseRequest(BaseModel):
    challenge_response: str


# ─────────────────────────────────────────────────────────────────────────────
# RESPONSE SCHEMAS  –  Session Result output models
# ─────────────────────────────────────────────────────────────────────────────

class AddressData(BaseModel):
    """Normalised postal address returned inside PersonData."""
    full_address: str | None = None    # person.address.fullAddress
    line1: str | None = None           # person.address.line1
    line2: str | None = None           # person.address.line2
    line3: str | None = None           # person.address.line3
    city: str | None = None            # person.address.city
    subdivision: str | None = None     # person.address.subdivision  (state/province)
    postal_code: str | None = None     # person.address.postalCode
    country: str | None = None         # person.address.country  (ISO 3166-1 alpha-2)

    class Config:
        populate_by_name = True


class PersonData(BaseModel):
    """
    Normalised person attributes.
    All fields are optional – availability depends on the provider used.
    See: https://docs.trinsic.id/docs/available-properties
    """
    given_name: str | None = None       # person.givenName
    family_name: str | None = None      # person.familyName
    middle_name: str | None = None      # person.middleName
    full_name: str | None = None        # person.fullName
    suffix: str | None = None           # person.suffix
    date_of_birth: str | None = None    # person.dateOfBirth  (ISO 8601 date)
    nationality: str | None = None      # person.nationality  (ISO 3166-1 alpha-2)
    sex: str | None = None              # person.sex  ("male" | "female" | "unknown")
    phone_number: str | None = None     # person.phoneNumber
    address: AddressData | None = None  # person.address.*


class DocumentData(BaseModel):
    """
    Normalised identity document attributes.
    Returned when the provider shares document-level data.
    """
    type: str | None = None                  # document.type  e.g. "passport", "drivers_license"
    number: str | None = None                # document.number
    issue_date: str | None = None            # document.issueDate  (ISO 8601 date)
    expiration_date: str | None = None       # document.expirationDate  (ISO 8601 date)
    issuing_country: str | None = None       # document.issuingCountry  (ISO 3166-1 alpha-2)
    issuing_authority: str | None = None     # document.issuingAuthority
    issuing_subdivision: str | None = None   # document.issuingSubdivision  (ISO 3166-2, Feb 2026+)


class MatchData(BaseModel):
    """
    Verification match results – boolean/score fields indicating what was
    verified against an authoritative source.
    """
    national_id_number: bool | None = None   # match.nationalIdNumber
    full_name: bool | None = None            # match.fullName
    given_name: bool | None = None           # match.givenName
    middle_name: bool | None = None          # match.middleName
    family_name: bool | None = None          # match.familyName
    sex: bool | None = None                  # match.sex
    date_of_birth: bool | None = None        # match.dateOfBirth
    face_match: float | None = None          # match.faceMatch  (confidence score 0-1)
    liveness: float | None = None            # match.liveness   (confidence score 0-1)
    image_authenticity: float | None = None  # match.imageAuthenticity


class Attachment(BaseModel):
    """
    A file attachment linked to a session result (Feb 2026 API format).
    Fetch the binary via POST /sessions/{sessionId}/attachments/{id}/get
    Attachment types:
      selfie, documentFront, documentBack, documentPortrait,
      documentSignature, provider.document-scan.report
    """
    id: str
    type: str           # e.g. "selfie", "document_front", "document_portrait"
    content_type: str   # MIME type, e.g. "image/png"
    size_bytes: int | None = None


class NormalizedIdentity(BaseModel):
    """
    The normalised identity data model returned by Trinsic.
    Aggregates person, document, match, and attachment data across all providers
    into a single consistent schema.
    """
    person: PersonData | None = None
    document: DocumentData | None = None
    match: MatchData | None = None
    # New attachment format (Feb 2026+). Use attachment.id to fetch binary.
    attachments: list[Attachment] | None = None
    # Deprecated (pre Feb 2026): attachment access keys map
    attachment_access_keys: dict[str, str] | None = None


class SessionOutcome(BaseModel):
    """
    Top-level outcome flags on a session result.
    Check `done` first, then `success` to determine final state.
    """
    done: bool                    # True when the session has concluded
    success: bool                 # True when verification succeeded
    error_code: str | None = None # Present when success=False and an error occurred
    error_message: str | None = None
    canceled: bool = False        # True if the user canceled the session


class SessionResultResponse(BaseModel):
    """
    Full response model for GET /sessions/{sessionId}/results.

    Structure:
      outcome        – session completion state (done/success/error/canceled)
      normalized     – cross-provider normalised identity data
      providerOutput – raw provider-specific output (varies per provider)
    """
    session_id: str
    outcome: SessionOutcome
    normalized: NormalizedIdentity | None = None
    # Raw provider-specific output; field names are provider IDs (e.g. "clear", "ca-mdl")
    provider_output: dict[str, Any] | None = None
