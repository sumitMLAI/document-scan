"""
Trinsic Identity Verification – FastAPI Backend
================================================
Session mode: Hosted Provider Session (Trinsic-hosted UI)

Trinsic API base: https://api.trinsic.id/api/v1
Auth:            Bearer <TRINSIC_API_KEY>

Endpoints exposed:
  Providers
    GET  /providers/                                          list all providers
    GET  /providers/{provider_id}                            get single provider

  Verification Profiles
    GET  /verification-profiles/                             list all profiles
    GET  /verification-profiles/{id}                         get single profile

  Sessions (per Verification Profile)
    POST /sessions/widget                                    create widget session
    POST /profiles/{vpId}/sessions/hosted                   create hosted session
    POST /profiles/{vpId}/sessions/direct                   create direct session
    GET  /profiles/{vpId}/sessions                          list sessions
    POST /profiles/{vpId}/recommend-providers               recommend providers

  Session operations
    GET  /sessions/{sessionId}                              get session metadata
    POST /sessions/{sessionId}/results                      get session results (needs resultsAccessKey)
    POST /sessions/{sessionId}/redact                       redact session PII
    POST /sessions/{sessionId}/cancel                       cancel session
    POST /sessions/{sessionId}/refresh-step-content         refresh expiring step content
    POST /sessions/{sessionId}/native-challenge-response    submit mDL/DC API challenge response
"""
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
import httpx

from app.routers import providers, sessions, verification_profiles

app = FastAPI(
    title="Trinsic Identity Verification API",
    description=(
        "FastAPI backend wrapping the Trinsic REST API. "
        "Covers all session types: Widget, Hosted Provider, and Direct Provider."
    ),
    version="1.0.0",
)

# ─── Routers ──────────────────────────────────────────────────────────────────
app.include_router(providers.router)
app.include_router(sessions.router)
app.include_router(verification_profiles.router)


# ─── Global error handler for Trinsic HTTP errors ─────────────────────────────
@app.exception_handler(httpx.HTTPStatusError)
async def trinsic_http_error(request: Request, exc: httpx.HTTPStatusError):
    try:
        detail = exc.response.json()
    except Exception:
        detail = exc.response.text
    return JSONResponse(
        status_code=exc.response.status_code,
        content={"error": "Trinsic API error", "detail": detail},
    )


@app.get("/", tags=["Health"])
async def health():
    return {"status": "ok", "service": "Trinsic Identity Verification API"}
